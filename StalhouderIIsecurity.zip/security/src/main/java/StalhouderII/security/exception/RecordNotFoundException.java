package StalhouderII.security.exception;

public class RecordNotFoundException extends Throwable {
    public RecordNotFoundException(){super();}
    public RecordNotFoundException(String message){super(message);}
}
