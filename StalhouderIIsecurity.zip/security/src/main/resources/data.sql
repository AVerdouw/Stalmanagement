INSERT INTO users (username, password, enabled) VALUES ('user', '', TRUE);
INSERT INTO users (username, password, enabled) VALUES ('admin', '', TRUE);

INSERT INTO authorities (username, authority) VALUES ('user', 'ROLE_USER');
INSERT INTO authorities (username, authority) VALUES ('admin', 'ROLE_USER');
INSERT INTO authorities (username, authority) VALUES ('admin', 'ROLE_ADMIN');