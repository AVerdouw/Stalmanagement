package stalmanagment.StalhouderII;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StalhouderIiApplicationTests {

	@Test
	void contextLoads() {
	}

}
